Group: RPG-Blasters
Names: Names: Mansoor Khan, Chris Sarkisyan, Manuel Cruz, and Nickolas Earles

Goal:
	The player must escape the dungeon. to do this you must collect the 2 keys on the far left and right of the map to open the way to the boss. kill it and then escape.


key binds:
arrow keys to move
space to attack
left alt to defend

Cheatcodes:
R to restart game
ecape to end game
1-9 on keypad to jump to room1-9
keypad / for 10
keypad * for 11
keypad - for 12
keypad + for 13
keypad . for 14
control for +100 hp to player
